import pygame
import sys
from pygame.locals import QUIT

pygame.init()

# CREATES CANVAS
DISPLAYSURF = pygame.display.set_mode((400, 300))
# TITLE OF CANVAS
pygame.display.set_caption('Hello World!')

# Loads the image
SpriteImage = pygame.image.load('aspen.png')
SpriteImage = pygame.transform.rotozoom(SpriteImage, 0, 2)
door = pygame.image.load('door.png')
door = pygame.transform.rotozoom(door, 0, 0.3)
tomato = pygame.image.load('tomato.png')
tomato = pygame.transform.rotozoom(tomato, 0, 0.5)
water = pygame.image.load('water.png')
water = pygame.transform.rotozoom(water, 0, 1)

aspen_x = 100
aspen_y = 100
bg_x = 0
bg_y = 0

outside_rect = pygame.Rect(36, 20, 120, 50)
inside_rect = pygame.Rect(300, 20, 100, 50)
aspen_rect = pygame.Rect(aspen_x,aspen_y,70,100)
milo_rect = pygame.Rect(36, 100, 100, 50)
pip_rect = pygame.Rect(300, 100, 100, 50)
forest_rect = pygame.Rect(250, 200, 100, 50)
left_rect = pygame.Rect(36, 70, 100, 50)
right_rect = pygame.Rect(250, 70, 100, 50)
tower_rect = pygame.Rect(200, 150, 100, 50)
enemy_rect = pygame.Rect(200, 150, 150, 50)

#CANVAS BACKGROUND
background1 = pygame.image.load('bedroom.jpeg')
background1 = pygame.transform.rotozoom(background1, 0, 1.7)
background2 = pygame.image.load('town.png')
background2 = pygame.transform.rotozoom(background2, 0, 1.3)
background_milo = pygame.image.load('shopkeeper.jpg')
background_milo = pygame.transform.rotozoom(background_milo, 0, 4.5)
background_pip = pygame.image.load('pip.jpg')
background_pip = pygame.transform.rotozoom(background_pip, 0, 4.5)
background3 = pygame.image.load('forest.jpg')
background3 = pygame.transform.rotozoom(background3, 0, 0.85)
background4 = pygame.image.load('tower.png')
background4 = pygame.transform.rotozoom(background4, 0, 1.2)
background5 = pygame.image.load('inner_tower.png')
background5 = pygame.transform.rotozoom(background5, 0, 2.5)

current_background = background1

game_active = True
delay = None
choice1 = outside_rect
choice1_text = "Outside"
choice2 = inside_rect
choice2_text = "Inside"

def miloChoice():
  global current_background, choice1, choice1_text, choice2, choice2_text, aspen_x, aspen_y
  current_background = background_milo
  print("\nAspen meets Milo the Fox, a shopkeeper. He warns that the village is in danger of an evil being residing in the forest.\nSave the village!\nMilo gives you a map of the forest...")
  aspen_x = 40
  aspen_y = 170
  choice1 = forest_rect
  choice2 = forest_rect
  choice1_text = "Forest"
  choice2_text = "Forest"

def pipChoice():
  global current_background, choice1, choice1_text, choice2, choice2_text, aspen_x, aspen_y
  current_background = background_pip
  print("\nAspen meets Pip the Squirrel, the town's news messenger. He warns that the village is in danger of an evil being residing in the forest.\nSave the village!\nPip tells Aspen that the enemy is hidden in a tower at the top of the mountains hidden in the forest...")
  aspen_x = 20
  aspen_y = 200
  choice1 = forest_rect
  choice2 = forest_rect
  choice1_text = "Forest"
  choice2_text = "Forest"

def potionIng():
  tomato = pygame.image.load('tomato.png')
  tomato = pygame.transform.rotozoom(tomato, 0, 3)

while True:
  for event in pygame.event.get():
      if event.type == QUIT:
           pygame.quit()
           sys.exit()
      elif event.type == pygame.MOUSEBUTTONDOWN:
        mouse_pos = pygame.mouse.get_pos()
        if aspen_rect.collidepoint(mouse_pos) and choice1 == outside_rect:
          print("Aspen the Raccoon wakes up. Click to go outside or stay inside...")
        elif outside_rect.collidepoint(mouse_pos):
          print("\nAspen goes outside and realizes they need their stuff. After going back inside, Aspen grabs their recurve bow...")
          current_background = background2
          choice1 = milo_rect
          choice1_text = "Milo"
          choice2 = pip_rect
          choice2_text = "Pip"
        elif inside_rect.collidepoint(mouse_pos):
          print("\nAspen grabs their recurve bow and continues to head outside...")
          current_background = background2
          choice1 = milo_rect
          choice1_text = "Milo"
          choice2 = pip_rect
          choice2_text = "Pip"
        elif milo_rect.collidepoint(mouse_pos):
          miloChoice()
        elif pip_rect.collidepoint(mouse_pos):
          pipChoice()
        elif forest_rect.collidepoint(mouse_pos):
          current_background = background3
          print("\nAspen ventures into the forest.\nThroughout the journey, Aspen collects berries, nuts, and stones.\nThe path splits into two. Which path should Aspen take?")
          choice1 = left_rect
          choice1_text = "Left"
          choice2 = right_rect
          choice2_text = "Right"
        elif left_rect.collidepoint(mouse_pos) or right_rect.collidepoint(mouse_pos):
          current_background = background4
          bg_x = -50
          print("\nAspen follows the path.\nAspen snacks on berries and nuts for energy.\nUp ahead, the enemy's tower is in sight!")
          choice1 = tower_rect
          choice1_text = "Tower"
          choice2 = tower_rect
          choice2_text = "Tower"
        elif tower_rect.collidepoint(mouse_pos):
          current_background = background5
          print("\nAs it turns out, the moment Aspen enters the tower, Aspen realizes the true enemy they were searching for was themself, for the tower had awakened the corruption within the village.\nThe end for now...")
          choice1 = enemy_rect
          choice1_text = "The Enemy"
          choice2 = enemy_rect
          choice2_text = "The Enemy"
          aspen_y = 200
   
  if game_active:
    DISPLAYSURF.blit(current_background, (bg_x, bg_y))
    DISPLAYSURF.blit(SpriteImage, (aspen_x,aspen_y))
    #DISPLAYSURF.blit(door, (250,100))
    pygame.draw.rect(DISPLAYSURF, (0,0,0), choice1)
    font = pygame.font.SysFont(None, 36)
    DISPLAYSURF.blit(font.render(choice1_text, True, (255, 255, 255)),
              (choice1.x + 20, choice1.y + 10))
                
    pygame.draw.rect(DISPLAYSURF, (0,0,0), choice2)
    DISPLAYSURF.blit(font.render(choice2_text, True, (255, 255, 255)),
              (choice2.x + 20, choice2.y + 10))
              
    if current_background == background3:
      DISPLAYSURF.blit(tomato, (200, 170))
      DISPLAYSURF.blit(water, (300, 170))
              
    pygame.display.update()

