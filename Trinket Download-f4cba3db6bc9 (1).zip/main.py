import pygame
import sys
from pygame.locals import QUIT

pygame.init()

# CREATES CANVAS
DISPLAYSURF = pygame.display.set_mode((400, 300))
# TITLE OF CANVAS
pygame.display.set_caption('Hello World!')

# Loads the image
SpriteImage = pygame.image.load('aspen.png')
SpriteImage = pygame.transform.rotozoom(SpriteImage, 0, 2)
door = pygame.image.load('door.png')
door = pygame.transform.rotozoom(door, 0, 0.3)

outside_rect = pygame.Rect(36, 20, 100, 50)
inside_rect = pygame.Rect(300, 20, 100, 50)

#CANVAS BACKGROUND
image = pygame.image.load('store_int_1.jpeg')
exit = False

game_active = True

while True:
   for event in pygame.event.get():
       if event.type == QUIT:
           pygame.quit()
           sys.exit()
   pygame.display.update()
   
   if game_active:
    DISPLAYSURF.blit(SpriteImage, (100,100))
    DISPLAYSURF.blit(door, (250,100))
    pygame.draw.rect(DISPLAYSURF, (0,0,0), outside_rect)
    font = pygame.font.SysFont(None, 36)
    DISPLAYSURF.blit(font.render('Outside', True, (255, 255, 255)),
              (outside_rect.x + 20, outside_rect.y + 10))
                
    pygame.draw.rect(DISPLAYSURF, (0,0,0), inside_rect)
    DISPLAYSURF.blit(font.render('Inside', True, (255, 255, 255)),
              (inside_rect.x + 20, inside_rect.y + 10))
    

